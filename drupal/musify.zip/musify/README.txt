musify filter Drupal module
=================================================

Marks up a tagged portion of text in musify, a quick mark-up for chords 
and rudimentary musical notation. 

Quickstart
------------------------------------------------------------------------

1. Move the entire "musify" directory into your Drupal installation's
   sites/all/modules folder (or your site specific directory).

2. Enable the module on Administer >> Site building >> Modules

3. Set up a new input format or add musify support to an existing format
at Administer >> Site configuration >> Input formats

4. I think will work best if this filter comes BEFORE a Markdown filter

For more information on musify visit http://musify.coreymwamba.co.uk
 
